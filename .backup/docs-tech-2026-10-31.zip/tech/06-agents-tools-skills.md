# 06 · 引擎 · 模型 · 工具

> 事实来源：`backend/app/agents/`、`backend/app/providers/`、`backend/app/tools/`、`backend/app/subagents/`

## 6.1 runtime — 引擎选择与降级判定 ★

`agents/runtime.py` 是运行时装配与"到底用哪个引擎"的裁决处。

### `prepare_engine()`（`:87-133`）

```text
expected_real = not mock_mode and provider != "mock"

if force_mock or not settings.real_model_configured:
    建 MockEngine
    degraded = False if force_mock else (self.degraded or expected_real)
else:
    真实模式 → await router.probe_chain()   （60s 缓存）
    探测通了 → 复位 degraded = False 并清空 degraded_reason
    全失败   → degraded = True + 记原因 + 建 MockEngine
```

> 历史坑：以前失败时只 `set degraded` 不清，导致进程重启前一直跑 mock，用户以为在跟大模型说话。现在**探测成功必须显式复位**。

### 关键结构

| 成员 | 作用 | 行号 |
|---|---|---|
| `AgentRuntime` | 持有 `degraded` / `degraded_reason` / `git_sha` / `extra` | `:70-84` |
| `EngineSelection(engine, mode, degraded, provider, model)` | 一次选择的结果 | `:61-67` |
| `health()` | 返回 status/version/**git_sha 与 git_sha_live**/mode/provider/model/degraded/degraded_reason/tools/subagents/skills/engines/approval_tools | `:136-159` |
| `load_prompt(name="system.md")` | 读提示词，正则抽 `version:`，剥掉首个 HTML 注释块 | `:171` |
| `read_skill(path)` | SKILL.md frontmatter 解析（已安装技能与技能库共用） | `:202` |
| `load_skills()` / `load_catalog()` | 扫 `*/SKILL.md`；技能库额外带 `slug` 与 `content_chars` | `:220` / `:240` |
| **`build_runtime(settings, storage)`** | 装配入口：提示词 + 技能 + 子智能体 + 工具 + 审批工具 + `ModelRouter` | `:261-292` |

常量：`PROMPTS_DIR = app/prompts`、`SKILLS_DIR = app/skills`、`CATALOG_DIR = app/skills_catalog`。

## 6.2 engine_protocol — 引擎接口

```python
class AgentEngine(Protocol):
    name: str
    def run(self, ctx: RunContext) -> AsyncIterator[EngineEvent]: ...
```

**唯一接口方法就是 `run`**。新增引擎（如 `deepagents`）只需实现该协议并在 `registry.py` 工厂里返回，事件协议/工具注册表/审批策略都不用动。

| 成员 | 说明 | 行号 |
|---|---|---|
| `RunContext` | 28 个字段：thread_id/run_id/trace_id/message/mode/model/degraded/messages/artifacts/approvals/tools/approval_tools/uploads/output_format/prompt_extra/project/approval_mode/history/context_summary/context_meta 等 | `:21-58` |
| `APPROVAL_MODES` | `always_ask` / `risky` / `all_allow`；`normalize_approval_mode()` 非法一律回落 `risky` | `:61` / `:64` |
| **`needs_approval(mode, tool_name, risk, approval_tools)`** | `all_allow` → 全放行；`always_ask` → `risk=="high"` 或在名单；`risky` → 只在名单里 | `:70-88` |
| `EngineEvent(event, data, comment=None)` | `comment` 是 SSE 心跳，**不落库** | `:91-97` |

## 6.3 上下文窗口（context_window.py）

| 默认值 | 值 | 行号 |
|---|---|---|
| `DEFAULT_MAX_TURNS` / `MAX_CHARS` / `MAX_TURN_CHARS` / `SUMMARY_CHARS` | 8 / 6000 / 1200 / 800 | `:33-36` |

| 方法 | 要点 | 行号 |
|---|---|---|
| `collect_turns(messages)` | 扁平消息聚成交替轮次，**按 `run_id` 分组**（时间戳只到秒，同秒内顺序不可靠）；`run_summary` 不进上下文；**没有助手回复的半截轮次丢弃**（否则重试时模型看到同一句出现两遍） | `:83-118` |
| `summarize_turns()` | **抽取式摘要，不调模型**；倒着写再翻回来，预算不够优先保最近 | `:127-149` |
| `build_plan()` | 从最近往前装；**最近一轮无论多长都要留下**（kept 为空时继续），否则"刚说完就失忆" | `:152-188` |
| `ContextPlan.meta()` | 产出 `context.compacted` 事件 data（turns_total/kept/dropped/summary_chars） | `:72` |

## 6.4 mock_engine — 演示引擎

`class MockEngine`（`name = "mock"`，646 行）。生成的是**固定模板的假步骤**，让演示完整可看。

步骤序列：

```text
run.started → 思考流 → opening 旁白（channel=process，不落库）
→ plan.updated(t1 in_progress)
→ file.list → tool.finished
→ plan.updated(t1 completed, t2 in_progress)
→ file.read（subagent_status="running"）→ tool.finished
→ 有素材则 doc.analyze_material（真跑 python 子进程，只读不写盘，故不触发审批）→ tool.finished
→ 决定模板与标题 → 第二次思考（讲"为什么用这个模板"）
→ plan.updated(t3 in_progress)
→ doc.generate_report（命中审批规则则先挂起）→ artifact.ready
→ 正式回复 + plan.updated + run.completed
```

| 细节 | 说明 | 行号 |
|---|---|---|
| 节奏 | `_pause(speed, factor)`，由 `mock_model_speed`（默认 0.05）控制 | `:644` |
| 思考模板 | `THINKING_TEMPLATE` **开工前只讲方法，不编交付物细节** | `:61-65` |
| 周报识别 | `WEEKLY_REQUEST_WORDS = ("周报","日报","月报","报告")` | `:68` |
| 扩展钩子 | `_enrich()` 可被子类覆盖（mock 不做事） | `:87` |

## 6.5 real_engine — 真实 LLM 引擎 ★

### 常量

| 常量 | 值 | 含义 |
|---|---|---|
| `MAX_STEPS_HARD_LIMIT` | 12 | 步数硬上限（与 `model_max_steps` 取小） |
| `OBSERVATION_LIMIT_CHARS` | 1800 | 普通工具回执超此长度转摘要 |
| `MATERIAL_OBSERVATION_LIMIT` | 7000 | `file.read` 正文注入上限 |
| `RESPONSE_CHUNK_CHARS` / `THINKING_CHUNK_CHARS` | 12 / 12 | 流式切片粒度 |
| `THINK_THOUGHT_MAX_TOKENS` | 360 | 思考过程独立调用的 token 预算 |

### 主循环 `run()`（`:226-397`）

```text
1. _reset + normalize_approval_mode + router.begin_run()
2. router.ensure_available() 为假 → 整条运行降级 _run_as_mock
3. 发 run.started（带 provider/engine）
4. 发首帧 plan.updated
5. _compose_thought() + _stream_thinking()   ← 先输出思考过程
6. _initial_messages(ctx) + tools.openai_tools()
7. for step in 1..max_steps:
     result = router.chat_with_tools(messages, tools, temperature, max_tokens)
     有文本 → _stream_text（还有 tool_calls 时 channel=process 旁白，否则 channel=reply 正式回复）
     无 tool_calls → finished_normally = True，break
     否则 → _assistant_message 入 messages + _execute_tool_calls
     每轮检查 token 预算
8. _reliability_fallback()
9. _mark_plan_done + 终帧 plan.updated
10. 发 run.completed（含 stop_reason / fallback_actions / usage）
```

### `_initial_messages()` 的前缀稳定策略 ★

顺序是刻意排的：

```text
system（基础提示词）→ TOOL_RULES →【产物格式】→ REPLY_RULES
→ prompt_extra（本轮需求路由规范，易变）
→ context_summary（更早对话要点，易变）
→ [system, *ctx.history, user]
```

理由（源码注释 `:401-404`）：

> DeepSeek 上下文缓存认**前缀**，前缀一变整段按未命中收费（¥1–2/百万），命中只要 ¥0.02–0.04，差 50 倍。把每轮都变的内容插在中间，会把后面几段稳定内容一起拖成未命中。

修复前后实测：缓存命中率 **0% → 96%**，两轮成本 ¥0.019 / ¥0.016。

### 工具调用循环 `_execute_tool_calls()`（`:523-689`）

```text
tools.resolve(name)
→ _clean_args（只保留 schema 声明的参数，容忍模型多传）
→ 未注册 → 发 tool.finished(ok=False) 并回 observation（不中断运行）
→ 需审批 → _approval_flow
→ 发 tool.started
→ await asyncio.to_thread(spec.handler, tool_ctx, **args)   ← 同步工具放线程
→ 异常 → 转 error.code="TOOL_ERROR"，不中断运行
→ 发 tool.finished
→ 按「本次新登记了哪些产物」补发 artifact.ready（artifacts_before 差集）
→ _advance_plan
→ observation 入 messages（file.read 额外注入 _material 正文）
```

| 细节 | 说明 |
|---|---|
| 计划推进 | `_advance_plan(tool, ok)` **按"做到哪一步"推进，而不是按工具名硬编码**；`doc.generate_report`/`code.run_python` 落地后直接收口 |
| 模型计划优先 | 模型写了 `todo.write` 就以模型计划为准（`_current_plan` `:470`） |
| 消息 id | `f"{run_id}_m{suffix}"`，保证跨 run 唯一 |

### 审批流 `_approval_flow()`（`:773-859`）

```text
approval_gate.create(...) → 发 approval.required（doc.generate_report 的 preview 特化为
title/template/format/impact）→ _wait_for_approval()
  └ 每 15s 发一个 heartbeat（防代理超时）
  ├ 超时   → _abort + stop_reason="approval_timeout" + run.failed(APPROVAL_TIMEOUT, retryable)
  ├ 拒绝   → tool.finished(ok=False, skipped=True, reason="approval_rejected") + 继续
  └ 批准   → 继续执行工具
```

### 可靠性兜底 `_reliability_fallback()`（`:691-763`）

模型"说完就停"时按意图补做：

```text
条件：命中 DOC_INTENT_KEYWORDS 且 无 artifact 且 有素材
    且 未命中 MODEL_REFUSAL_MARKERS（模型说做不了）
→ 补 doc.generate_report（走审批），成功则 stop_reason="fallback"
→ 先补生成再说话（这样收尾这句话能带上文件名）
```

> 为什么检查拒答：结论说没产出、下面又冒出文件，会自相矛盾。

### 其他

| 成员 | 说明 | 行号 |
|---|---|---|
| `_run_as_mock(ctx, event)` | 无可用供应商时整条交给 MockEngine，**跳过其重复的 run.started** | `:883-909` |
| `_degrade_midrun()` | 运行中模型不可用：发降级说明 + 收口计划 + `run.completed(degraded=True)` | `:911-947` |
| `_stream_thinking()` / `_compose_thought()` | 思考是**模型现场写的推理，不是写死模板**；用独立一次 `chat_with_tools(tools=None, temperature=0.4, max_tokens=360)`，失败/超时退回可读兜底 | `:950` / `:983` |
| `_stream_text(channel)` | `channel="reply"` 落 messages 表；`"process"` 不落库（重开会话只该看到问题+最终回复） | `:1026` |
| 按任务类型分派计划 | `PLAN_FORMAT` / `PLAN_DOC` / `PLAN_EXTRACT` / `PLAN_CODE` / `PLAN_ANSWER` + `_PLAN_KEYWORDS` | `:97-131` |

## 6.6 model_router — 供应商路由 ★

### 常量

| 常量 | 值 |
|---|---|
| `PROBE_CACHE_TTL_SECONDS` | 60 |
| `RETRY_BACKOFF_SECONDS` | 1.0 |
| `CIRCUIT_COOLDOWN_SECONDS` | 60 |
| `TOKEN_BUDGET_PER_RUN` | 200_000 |
| `RECEIPT_LIMIT` | 40 |

### 并发安全的用量计

```python
_CURRENT_METER: ContextVar[_MeterSlot | None]
```

> 改造前 `begin_run()` 换掉 `self._usage`，两个会话并发跑时 B 的 begin_run 会把 A 累计的 tokens 清零，账单与预算判断全错。改成 ContextVar 后每个 run 在自己的任务上下文里拿到自己的计；槽位带 router 身份防止多路由实例串账。

### 主流程

| 方法 | 要点 | 行号 |
|---|---|---|
| `chain(start=None)` | 顺序：`start → 主供应商 → fallback 链`，去重并去掉 mock | `:257-265` |
| `begin_run(preferred)` | 为当前任务上下文换一只新 `UsageAccumulator`（`budget=model_token_budget`） | `:343-355` |
| **`chat_with_tools(...)`** | 遍历链 → 未配置记 `skipped: 未配置（缺少 Key）` → 熔断中记 `skipped: 熔断冷却中` → `_call_with_retry()` → 成功则记 `preferred` 并复位 `_degraded`；全失败 → `degraded=True` + 抛 `ModelUnavailableError` | `:408-450` |
| `probe(provider, force)` | 单供应商探测，**60s 缓存**，探测绝不冒泡异常 | `:452-481` |
| `probe_chain()` | 逐家探测，返回 `(首个可用 provider, "")` 或 `(None, "；".join(reasons))` | `:483-497` |
| `ensure_available()` | **不发网络请求**的可用性判断（供引擎决定是否直接降级） | `:499-513` |
| `reset_providers()` | 清 provider 实例/探测缓存/熔断计时（设置改了立即生效） | `:534-543` |
| `_invoke()` | 调 provider → 算延迟 → **无 request_id 时打 `model_call_unverified` 警告** → 计价 → 累计 → 打 `model_call` 日志 | `:561-633` |
| **`_call_with_retry()`** | 见下 | `:635-681` |
| `estimate_cost(...)` | `cache_miss` 缺省时按 `prompt_tokens - hit` 算（**上限，宁高不低**） | `:683-712` |

### 重试策略（按错误类别）

| 类别 | 行为 |
|---|---|
| `AUTH`（401/403） | **立即熔断 60s 并切换**，不重试 |
| `RATE_LIMIT`（429）/ `TIMEOUT` / `NETWORK` | 第 0 次：退避 1s 重试一次 |
| 5xx `SERVER` / `BAD_FORMAT` | 立即切换下一家 |
| `UNCONFIGURED` | 跳过 |

最多 2 次尝试（`for attempt in range(2)`）。

### 数据结构

| 结构 | 字段 |
|---|---|
| `ChatResult` | text / provider / model / prompt_tokens / completion_tokens / tool_calls / finish_reason / cost_cny / **cache_hit_tokens / cache_miss_tokens** / peak / **request_id** / latency_ms |
| `UsageAccumulator` | input/output/cache_hit/cache_miss / cost_cny / calls / by_provider / budget / receipts（≤40 条，含 `verified=bool(request_id)`） |
| `as_dict()` | 额外给 `calls_detail` / `verified_calls` / `budget` / `currency("CNY")` |

## 6.7 providers — 供应商适配器

### 支持的 5 家

| 供应商 | 默认端点 | 默认模型 | Key 环境变量 |
|---|---|---|---|
| deepseek | `https://api.deepseek.com/v1` | `deepseek-flash` | `DEEPSEEK_API_KEY`（兼容 `OPENAI_API_KEY`） |
| qwen | `https://dashscope.aliyuncs.com/compatible-mode/v1` | `qwen-plus` | `DASHSCOPE_API_KEY` / `QWEN_API_KEY` |
| glm | `https://open.bigmodel.cn/api/paas/v4` | `glm-4-plus` | `GLM_API_KEY` |
| openai | `https://api.openai.com/v1` | `gpt-4o-mini` | `OPENAI_API_KEY` |
| workbuddy | **无公共默认值，必须用户填** | `workbuddy-chat` | `WORKBUDDY_API_KEY` |

> `deepseek-chat` 是官方会静默路由到 `deepseek-flash` 的**旧别名**。

### 错误分类（7 类）

| 类别 | 触发 | `retryable` |
|---|---|---|
| `AUTH` | 401 / 403 | 否（熔断） |
| `RATE_LIMIT` | 429 | 是 |
| `TIMEOUT` | 超时 | 是 |
| `SERVER` | 5xx | 否 |
| `BAD_FORMAT` | 缺 choices / tool_calls 不合法 | 否 |
| `NETWORK` | 连接/DNS/代理 | 是 |
| `UNCONFIGURED` | 无 Key 或 Base URL | — |

### `ProviderResult` 字段

`text / tool_calls / finish_reason / model / prompt_tokens / completion_tokens / cache_hit_tokens / cache_miss_tokens / request_id`

- `cache_hit` / `cache_miss` 用于按两档计价（单价差 50 倍）。
- `request_id` 是"这真是一次外部调用"的凭据，审计页据此统计 `verified_calls`。

### `chat()` 的空正文/截断重试 ★

```text
budgets = [max_tokens, min(max(max_tokens*3, 6000), 16000)]

对每个预算：
  _post → truncated = (finish_reason == "length")
  _parse_result(data, allow_empty=True)
  若 BAD_FORMAT 且 truncated 且还有下一个预算 → 记 model_truncated_retry 后放大重试
  若正文与 tool_calls 都空 且 truncated → 记 model_empty_retry 后放大重试
最终仍空 → 抛 BAD_FORMAT（带 finish_reason 与已放到多大的预算）
```

为什么要放大预算：

> 推理模型（如 deepseek-flash）先写 `reasoning_content`，`max_tokens` 太小时正文就是空串——**这不是故障**。而工具参数是一整段 JSON，2000 的输出预算常在参数中间被截断。

### `probe()` 的判据

> 判据是「**端点是否给出合法回执**」，不是「有没有正文」。

改之前要正文非空，deepseek-flash 必然探测失败，进而把整个引擎静默降级成 mock——用户以为在跟大模型说话，其实是本地脚本。现在用 `max_tokens=32, allow_empty=True`。

### 回执解析

| 项 | 说明 |
|---|---|
| 缓存字段 | 认两种写法：`usage.prompt_cache_hit_tokens`（DeepSeek）或 `usage.prompt_tokens_details.cached_tokens`（OpenAI） |
| miss 缺失 | 按 `prompt_tokens - hit` 推 |
| request_id | 取 `data["id"]` |
| 出网前 | `_assert_base_url_allowed()` 兜底 SSRF 校验 |

## 6.8 tools — 工具系统

### 注册机制

```python
@tool("file.read", description="...", risk=Risk.LOW)
def read_file(ctx: ToolContext, ...) -> dict: ...
```

| 机制 | 说明 | 行号 |
|---|---|---|
| 工具名规则 | 必须匹配 `^[a-z0-9]+(?:\.[a-z0-9_]+)+$` | `spec.py:140` |
| Schema 自动生成 | `build_schema(handler)` 由函数签名生成 JSON Schema：跳过首个 `ctx` 参数与 `_` 开头的私有参数；有默认值的写 `default`，无默认值的进 `required` | `spec.py:90` |
| OpenAI 名映射 | `file.read` → `file_read`（function 名只允许 `[a-zA-Z0-9_-]`）；`resolve()` 两种写法都认 | `spec.py:116` / `:195` |
| 高风险描述 | 自动追加「（高风险：内核会在执行前请求用户审批）」 | `spec.py:121` |
| 审批名单 | `approval_tools(rules)` = `risk==HIGH and name in rules` | `spec.py:183` |

### 工具清单

| 工具 | 风险 | 默认审批 | 功能 |
|---|---|---|---|
| `file.list` | low | 否 | 列出会话已上传素材（文件名/字数/解析状态） |
| `file.read` | low | 否 | 读取素材正文 |
| `file.delete` | **high** | ✅ | 删除本会话产物（软删入回收站） |
| `todo.write` / `todo.list` | low | 否 | 写入/读取任务计划 |
| `doc.analyze_material` | low | 否 | **只读**脚本体检素材结构（段落/字数/标题层级/图片/表格/关键句） |
| `doc.generate_report` | **high** | 否 | 按模板生成报告产物并登记 |
| `code.run_python` | **high** | ✅ | 受控目录执行 Python 脚本 |
| — | — | — | `xlsx.py` 当前**不注册工具**，只提供纯函数 `summarize_workbook` |

> `doc.generate_report` 虽是 high，但默认审批规则不含它（写的是产物目录，可覆盖可重跑，不必每次点确认）。`approval_mode=always_ask` 时它才会被拦。

### `code.run_python` 沙箱 ★

**它不是内核级沙箱**——脚本仍能访问本机文件系统，所以默认必须人工确认。

| 机制 | 实现 |
|---|---|
| 环境变量白名单 | 只含 `PATH / SYSTEMROOT / WINDIR / COMSPEC / TEMP / TMP / HOME / USERPROFILE / APPDATA / LOCALAPPDATA / LANG / LC_ALL`——**不含任何 API Key / token** |
| 注入变量 | `OA_INPUT_DIR`=`<root>/in`（目录）、`OA_OUTPUT_DIR`=`<root>/out`、`OA_ARTIFACT_DIR`、`OA_UPLOAD_DIR`、`OA_INPUTS`=JSON 清单（含 filename/path/ext/chars，**不是目录**）、`OA_RUN_DIR` |
| 工作目录 | `<artifact_dir>/../workspace/<run_id>/{in,out}` |
| 工具库 | `UTIL_MODULES = (docx_utils, pdf_utils, xlsx_utils, text_utils)` 复制进工作目录，脚本可 `from docx_utils import *` |
| 子进程 | `subprocess.run([sys.executable, script], cwd=root, env=child_env, timeout=...)`；超时 `exit_code=-1` 并在 stderr 写明 |
| 超时 | `max(5, min(120, timeout_seconds))` |
| 产物登记 | 按扩展名白名单 + 30MB 上限 + **sha256 比对**（内容没变记 `unchanged` 不重复登记）+ 同名重写（旧版软删并记 `superseded`） |
| **失败不登记** | `ok=False` 时 `registered=[]`——"脚本失败也登记，半成品 docx 一打开就是坏的" |
| 缺失文件回报 | 点名了但会话里没有的文件会列进 `missing`，避免脚本 glob 空目录报 `IndexError` 看起来像代码写错 |
| 错误提示 | 取 traceback 最后一句真正的异常；`TypeError` 未预期关键字参数时把真实签名递过去；`NameError` 时用 `difflib` 找最接近的导出名（AST 读 `__all__`，不执行脚本） |

## 6.9 subagents — 子智能体

| 名称 | 状态 | 工具 | 行为 |
|---|---|---|---|
| `doc_agent` | `implemented` | `file.read`, `doc.generate_report` | 读素材 → 生成 weekly 报告 → 返回 `{ok, agent, tool_results, artifact_id, summary}` |
| `research_agent` | `placeholder` | — | 预留联网检索，当前返回 `NOT_IMPLEMENTED` |
| `sheet_agent` | `placeholder` | — | 预留表格清洗，当前返回 `NOT_IMPLEMENTED` |

注册：`@subagent(name, description, prompt, tools, status, step_limit)` → `SUBAGENT_REGISTRY`。

## 6.10 skills 与 skills_catalog

| 项 | 内容 |
|---|---|
| 已安装技能目录 | `backend/app/skills/`（6 个：data-brief、doc-qc、meeting-minutes、outline-first、project-retro、weekly-report） |
| 技能库目录 | `backend/app/skills_catalog/`（5 个） |
| 文件格式 | `<slug>/SKILL.md`，frontmatter 含 `name` / `description` / `triggers` / `enabled`，展示用 `title` / `category` / `icon` / `badge` |
| 提示词注入 | 基础提示词 + 「# 可用技能（按需参考）」+ 各启用技能正文 |
| 启停存储 | settings 表键 `skills.disabled` |
| 删除 | 挪进 `app/skills/.trash/<name>-<时间戳>` |
| **未安装的技能不进提示词** | 技能库只供一键安装 |

## 6.11 prompt packs

目录 `backend/app/prompts/packs`。按需求关键词自动匹配并注入本轮 system prompt：

- `MAX_PACKS_PER_RUN = 2`
- `MAX_INJECT_CHARS = 4200`
- 主提示词：`backend/app/prompts/system.md`

## 6.12 plugins（可选扩展）

`backend/app/plugins.py`：通过 `importlib.metadata.entry_points(group="office_agent.plugins")` 发现插件并调用 `register(registry)`。单个插件加载失败只 warning 不中断；已加载插件名存进 `runtime.extra["plugins"]`。当前无内置插件。
